"""
NOUS HTTP API Server — v4.0.0
FastAPI + uvicorn. No external agent frameworks.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import py_compile
import tempfile
import time
import traceback
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

load_dotenv(Path(__file__).parent.parent / ".env")

NOUS_DIR = Path(__file__).parent
TEMPLATES_DIR = NOUS_DIR / "templates"
LOG_FILE = Path("/var/log/nous_api.log")
VERSION = "4.0.0"
START_TIME = time.time()

API_KEYS: set[str] = set()
raw_keys = os.getenv("NOUS_API_KEYS", "")
if raw_keys:
    API_KEYS = {k.strip() for k in raw_keys.split(",") if k.strip()}


# ── Logging ──

log_handler = logging.FileHandler(LOG_FILE)
log_handler.setFormatter(logging.Formatter(
    '{"ts":"%(asctime)s","level":"%(levelname)s","msg":"%(message)s"}'
))
logger = logging.getLogger("nous_api")
logger.setLevel(logging.INFO)
logger.addHandler(log_handler)
logger.addHandler(logging.StreamHandler())


# ── Rate Limiter ──

limiter = Limiter(key_func=get_remote_address)


# ── NOUS Imports ──

import sys
if str(NOUS_DIR) not in sys.path:
    sys.path.insert(0, str(NOUS_DIR))

from parser import parse_nous
from validator import NousValidator
from typechecker import typecheck_program
from verifier import verify_program
from codegen import NousCodeGen


# ── Models ──

class CompileRequest(BaseModel):
    source: str = Field(..., min_length=1, max_length=100_000)

class VerifyRequest(BaseModel):
    source: str = Field(..., min_length=1, max_length=100_000)

class RunRequest(BaseModel):
    source: str = Field(..., min_length=1, max_length=100_000)
    mode: str = Field(default="dry-run", pattern="^(dry-run|execute)$")
    max_cycles: int = Field(default=3, ge=1, le=100)

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=10_000)
    session_id: Optional[str] = None
    soul: Optional[str] = None

class WebhookPayload(BaseModel):
    data: Any = None


class ErrorResponse(BaseModel):
    error: str
    code: str


# ── Auth ──

def require_api_key(x_api_key: Optional[str] = Header(None)) -> str:
    if not API_KEYS:
        return "no-auth"
    if not x_api_key or x_api_key not in API_KEYS:
        raise HTTPException(status_code=401, detail={"error": "Invalid or missing API key", "code": "AUTH001"})
    return x_api_key


# ── App ──

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"NOUS API v{VERSION} starting")
    TEMPLATES_DIR.mkdir(exist_ok=True)
    yield
    logger.info("NOUS API shutting down")

app = FastAPI(
    title="NOUS API",
    version=VERSION,
    description="HTTP API for the NOUS programming language",
    lifespan=lifespan,
)

app.state.limiter = limiter

@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(
        status_code=429,
        content={"error": "Rate limit exceeded", "code": "RATE001"},
    )

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Helpers ──

def _compile_pipeline(source: str) -> dict[str, Any]:
    program = parse_nous(source)

    val_result = NousValidator(program).validate()
    val_errors = [{"code": e.code, "severity": e.severity, "message": e.message, "location": e.location} for e in val_result.errors]
    val_warnings = [{"code": w.code, "severity": w.severity, "message": w.message, "location": w.location} for w in val_result.warnings]

    if not val_result.ok:
        return {
            "ok": False,
            "stage": "validate",
            "errors": val_errors,
            "warnings": val_warnings,
        }

    tc_result = typecheck_program(program)
    tc_errors = [{"code": e.code, "message": e.message} for e in tc_result.errors]
    tc_warnings = [{"code": w.code, "message": w.message} for w in tc_result.warnings]

    if not tc_result.ok:
        return {
            "ok": False,
            "stage": "typecheck",
            "errors": tc_errors,
            "warnings": val_warnings + tc_warnings,
        }

    gen = NousCodeGen(program)
    python_code = gen.generate()

    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write(python_code)
        tmp_path = f.name

    try:
        py_compile.compile(tmp_path, doraise=True)
    except py_compile.PyCompileError as e:
        return {
            "ok": False,
            "stage": "py_compile",
            "errors": [{"code": "PY001", "message": str(e)}],
            "warnings": val_warnings + tc_warnings,
        }
    finally:
        os.unlink(tmp_path)

    lines = python_code.strip().split("\n")
    soul_count = len(program.souls)
    message_count = len(program.messages)

    return {
        "ok": True,
        "stage": "complete",
        "python": python_code,
        "lines": len(lines),
        "souls": soul_count,
        "messages": message_count,
        "world": program.world.name if program.world else None,
        "errors": [],
        "warnings": val_warnings + tc_warnings,
    }


# ── Endpoints ──

@app.get("/v1/health")
@limiter.limit("200/minute")
async def health(request: Request):
    uptime = int(time.time() - START_TIME)
    return {
        "status": "ok",
        "version": VERSION,
        "uptime_seconds": uptime,
        "engines": 8,
        "subsystems": 12,
        "cli_commands": 43,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.post("/v1/compile")
@limiter.limit("100/minute")
async def compile_source(request: Request, body: CompileRequest, x_api_key: Optional[str] = Header(None)):
    require_api_key(x_api_key)
    logger.info(f"compile request: {len(body.source)} chars")

    try:
        result = await asyncio.wait_for(
            asyncio.get_event_loop().run_in_executor(None, _compile_pipeline, body.source),
            timeout=30.0,
        )
        return result
    except asyncio.TimeoutError:
        raise HTTPException(status_code=408, detail={"error": "Compilation timed out (30s)", "code": "TIMEOUT001"})
    except Exception as e:
        logger.error(f"compile error: {traceback.format_exc()}")
        raise HTTPException(status_code=422, detail={"error": str(e), "code": "COMPILE001"})


@app.post("/v1/verify")
@limiter.limit("100/minute")
async def verify_source(request: Request, body: VerifyRequest, x_api_key: Optional[str] = Header(None)):
    require_api_key(x_api_key)
    logger.info(f"verify request: {len(body.source)} chars")

    try:
        def _do_verify():
            program = parse_nous(body.source)

            val_result = NousValidator(program).validate()
            if not val_result.ok:
                return {
                    "ok": False,
                    "stage": "validate",
                    "proven": [],
                    "errors": [{"code": e.code, "message": e.message} for e in val_result.errors],
                    "warnings": [{"code": w.code, "message": w.message} for w in val_result.warnings],
                }

            ver_result = verify_program(program)

            proven = []
            warnings = []
            errors = []
            for item in ver_result.items:
                entry = {
                    "code": item.code,
                    "category": item.category,
                    "message": item.message,
                    "severity": item.severity.value if hasattr(item.severity, 'value') else str(item.severity),
                }
                if item.severity.value == "ERROR" if hasattr(item.severity, 'value') else str(item.severity) == "ERROR":
                    errors.append(entry)
                elif item.severity.value == "WARN" if hasattr(item.severity, 'value') else str(item.severity) == "WARN":
                    warnings.append(entry)
                else:
                    proven.append(entry)

            return {
                "ok": len(errors) == 0,
                "stage": "complete",
                "proven": proven,
                "errors": errors,
                "warnings": warnings,
                "total_checks": len(ver_result.items),
            }

        result = await asyncio.wait_for(
            asyncio.get_event_loop().run_in_executor(None, _do_verify),
            timeout=30.0,
        )
        return result
    except asyncio.TimeoutError:
        raise HTTPException(status_code=408, detail={"error": "Verification timed out (30s)", "code": "TIMEOUT002"})
    except Exception as e:
        logger.error(f"verify error: {traceback.format_exc()}")
        raise HTTPException(status_code=422, detail={"error": str(e), "code": "VERIFY001"})


@app.post("/v1/run")
@limiter.limit("30/minute")
async def run_source(request: Request, body: RunRequest, x_api_key: Optional[str] = Header(None)):
    require_api_key(x_api_key)
    logger.info(f"run request: {len(body.source)} chars, mode={body.mode}, cycles={body.max_cycles}")

    try:
        def _do_run():
            compile_result = _compile_pipeline(body.source)
            if not compile_result["ok"]:
                return {
                    "ok": False,
                    "stage": compile_result["stage"],
                    "errors": compile_result["errors"],
                    "output": None,
                }

            if body.mode == "dry-run":
                return {
                    "ok": True,
                    "mode": "dry-run",
                    "compiled": True,
                    "lines": compile_result["lines"],
                    "souls": compile_result["souls"],
                    "messages": compile_result["messages"],
                    "world": compile_result["world"],
                    "output": "Dry run complete. Code compiles and verifies successfully.",
                    "warnings": compile_result["warnings"],
                }

            return {
                "ok": True,
                "mode": "execute",
                "output": "Live execution not yet available via API. Use dry-run mode or nous run on the server.",
                "compiled": True,
                "lines": compile_result["lines"],
                "souls": compile_result["souls"],
            }

        result = await asyncio.wait_for(
            asyncio.get_event_loop().run_in_executor(None, _do_run),
            timeout=60.0,
        )
        return result
    except asyncio.TimeoutError:
        raise HTTPException(status_code=408, detail={"error": "Run timed out (60s)", "code": "TIMEOUT003"})
    except Exception as e:
        logger.error(f"run error: {traceback.format_exc()}")
        raise HTTPException(status_code=422, detail={"error": str(e), "code": "RUN001"})


@app.post("/v1/chat")
@limiter.limit("60/minute")
async def chat(request: Request, body: ChatRequest, x_api_key: Optional[str] = Header(None)):
    require_api_key(x_api_key)
    session = body.session_id or str(uuid.uuid4())
    logger.info(f"chat request: session={session}, soul={body.soul}")

    return {
        "reply": f"Chat endpoint ready. Message received: \"{body.message[:100]}\"",
        "confidence": 0.0,
        "soul": body.soul or "Triage",
        "session_id": session,
        "cost": 0.0,
        "note": "Chat routing requires a running NOUS world. Configure a .nous program with chat-enabled souls to activate.",
    }


@app.get("/v1/templates")
@limiter.limit("200/minute")
async def list_templates(request: Request):
    templates = []
    if TEMPLATES_DIR.exists():
        for f in sorted(TEMPLATES_DIR.glob("*.nous")):
            source = f.read_text(encoding="utf-8")
            soul_count = source.count("soul ")
            lines = len(source.strip().split("\n"))
            templates.append({
                "name": f.stem,
                "file": f.name,
                "souls": soul_count,
                "lines": lines,
                "size": len(source),
            })
    return {"templates": templates, "count": len(templates)}


@app.get("/v1/templates/{name}")
@limiter.limit("200/minute")
async def get_template(request: Request, name: str):
    path = TEMPLATES_DIR / f"{name}.nous"
    if not path.exists():
        raise HTTPException(status_code=404, detail={"error": f"Template '{name}' not found", "code": "TPL001"})

    source = path.read_text(encoding="utf-8")
    return {
        "name": name,
        "file": path.name,
        "source": source,
        "lines": len(source.strip().split("\n")),
    }


@app.post("/v1/webhook/{channel}")
@limiter.limit("100/minute")
async def webhook(request: Request, channel: str, x_api_key: Optional[str] = Header(None)):
    require_api_key(x_api_key)

    try:
        raw = await request.body()
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = {"raw": raw.decode("utf-8", errors="replace")}
    except Exception:
        payload = {}

    event_id = str(uuid.uuid4())
    logger.info(f"webhook: channel={channel}, event={event_id}, size={len(raw)}")

    return {
        "received": True,
        "channel": channel,
        "event_id": event_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "note": "Webhook received. Configure a NOUS world with webhook-enabled souls to process events.",
    }


# ── Error Handlers ──

# 422 handler removed — let FastAPI show real errors

@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    logger.error(f"Internal error: {traceback.format_exc()}")
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "code": "INTERNAL001"},
    )
